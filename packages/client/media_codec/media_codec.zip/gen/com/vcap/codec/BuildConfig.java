/** Automatically generated file. DO NOT MODIFY */
package com.vcap.codec;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}