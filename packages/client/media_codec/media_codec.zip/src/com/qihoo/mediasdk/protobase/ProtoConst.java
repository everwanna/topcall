package com.qihoo.mediasdk.protobase;

public class ProtoConst {
	public static final int	PROTO_TCP_BUFFER_SIZE = 256*1024;
	public static final int	PROTO_UDP_BUFFER_SIZE = 32*1024;
	public static final int	PROTO_PACKET_SIZE = 8*1024;
}
