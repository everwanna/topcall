package com.qihoo.mediasdk.audio.record;

public interface IRecordMgr {
	void startRecord();
	void stopRecord();
}
