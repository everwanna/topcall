package com.qihoo.mediasdk.net;

public class NetTimer {
	public int linkid = 0;
	public int id = 0;
	public int interval = 0;
	public long last = 0;
}
