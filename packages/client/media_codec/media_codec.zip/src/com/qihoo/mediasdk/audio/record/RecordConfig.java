package com.qihoo.mediasdk.audio.record;

public class RecordConfig {
	public int header_size = 0;
	public int sample_rate = 0;
	public int bit_rate = 0;
	public int frame_size = 0;
	public int byte_0 = 0;
	public boolean vbr = false;	
}
