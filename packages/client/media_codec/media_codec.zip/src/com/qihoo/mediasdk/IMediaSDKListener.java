package com.qihoo.mediasdk;

public interface IMediaSDKListener {
	void	onLogin();
}	
