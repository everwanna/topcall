package com.qihoo.mediasdk.protobase;

public class ProtoSvid {
	public static final short SVID_IDC_PUSH = 1;
	public static final short SVID_MPROXY = 2;
	public static final short SVID_MGROUP = 4;	
	public static final short SVID_MCENTER = 5;
	public static final short SVID_MCPROXY = 6;
	
}
